public class RealizaCompra {
    public static void main (String args[]){
        Atendente a = new Atendente();
        Compra co = new Compra();
        ListaDeProdutos ldp = new ListaDeProdutos();
        PontoDeVendas pdv = new PontoDeVendas();
        Produtos p = new Produtos();
        pdv.Iniciar();
        co.Iniciar();
        a.Registrar("produto");
        pdv.Buscar();
        pdv.DeterminarPreco();
        a.Registrar("produto");
        pdv.Buscar();
        pdv.DeterminarPreco();
        a.Registrar("produto");
        pdv.Buscar();
        pdv.DeterminarPreco();
        co.Adicionar();
        a.Finalizar();
        pdv.Calcular();
        pdv.Imprimir(); 
        a.Registrar("pagamento");
        co.Pagaremdinheiro();
        pdv.Mostrar();
        pdv.Gerar();
        a.Depositar();
        a.Devolver();
        a.Registrar("pagamento");
        pdv.Gerar();
        pdv.Depositar();
        pdv.Imprimir();
        pdv.Finalizar();
    }
}
