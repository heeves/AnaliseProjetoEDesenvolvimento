public class ListaDeProdutos {
    public int codigodeproduto;
    public Compra compra;
    public Produtos produtos;
    public int quantidade;
    public String Validade;
    public void Atualizar(){
        System.out.println("Atualizando lista de produtos...");
    }
}
