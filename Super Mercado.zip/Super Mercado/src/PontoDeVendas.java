
public class PontoDeVendas {
    public int itens;
    public float troco;
    public Atendente atendente;
    public void Iniciar(){
        System.out.println("Iniciando caixa...");
    }
    public void DeterminarPreco(){
        System.out.println("Determinando Preços...");
    }
    public void Calcular(){
        System.out.println("Calculando Nota...");
    }
    public void Gerar(){
        System.out.println("Gerando Recibo...");
    }
    public void Depositar(){
        System.out.println("Depositando...");
    }
    public void Imprimir(){
        System.out.println("Imprimindo nota...");
    }
    public void Finalizar(){
        System.out.println("Finalizando...");
    }
    public void Registrar(){
        System.out.println("Registrando...");
    }
    public void Mostrar(){
        System.out.println("Mostrando o troco...");
    }
    public void Buscar(){
        System.out.println("Buscando produtos...");
    }
}
