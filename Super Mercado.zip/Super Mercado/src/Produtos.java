public class Produtos {
    public String origem;
    public String validade;
    public String aquisicao;
    public float preco;
    public ListaDeProdutos listadeprodutos;
    public void Incluir(){
        System.out.println("Incluindo produtos...");
    }
    public void Comprar(){
        System.out.println("Comprando produtos...");
    }
    public void Repor(){
        System.out.println("Repondo produtos...");
    }
}
