public class Compra {
    public ListaDeProdutos listadeprodutos;
    public PontoDeVendas pontodevendas;
    public String produtos;
    public void Iniciar(){
        System.out.println("Iniciando compra...");
    }
    public void Adicionar(){
        System.out.println("Adicionando na compra...");
    }
    public void Finalizar(){
        System.out.println("Finalizando compra...");
    }
    public void Pagaremdinheiro(){
        System.out.println("Recebendo dinheiro...");
    }
    public void Pagaremcheque(String banco, String numerodocheque, String nomedocomprador){
        System.out.println("Recebendo cheque...");
    }
}
