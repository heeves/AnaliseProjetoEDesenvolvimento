public class Atendente {
    public String nome;
    public String datadeadmissao;
    public int idade;
    public PontoDeVendas pontodevendas;
    public void Iniciar(){
        System.out.println("Iniciando atendimento...");
    }
    public void Receber(){
        System.out.println("Recebendo dinheiro...");
    }
    public void Depositar(){
        System.out.println("Depositando dinheiro...");
    }
    public void Finalizar(){
        System.out.println("Finalizando compra...");
    }
    public void Registrar(String x){
        if(x.equals("produtos"))
            System.out.println("Registrando produtos...");
        else
            System.out.println("Registrando pagamento...");
    }
    public void Devolver(){
        System.out.println("Devolvendo troco...");
    }
}
 