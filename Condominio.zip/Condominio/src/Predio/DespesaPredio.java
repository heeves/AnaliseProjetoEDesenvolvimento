
package Predio;

public class DespesaPredio {
    public int numeroDespesa;
    public String nomeDespesa;
    public float valorDespesa;
    public String mesAnoDespesa;
    public DespesaApartamento[] despesa_apartamento;
    public Incluir(int novoNumeroDespesa, String novoNomeDespesa, float novoValorDespesa, String novoMesAnoDespesa, DespesaApartamento[] novaDespesa_Apartamento){
        numeroDespesa = novoNumeroDespesa;
        nomeDespesa = novoNomeDespesa;
        valorDespesa = novoValorDespesa;
        mesAnoDespesa = novoMesAnoDespesa;
        despesa_apartamento = novaDespesa_Apartamento;
    }
}
