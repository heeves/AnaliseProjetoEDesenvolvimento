
package Predio;

public class TesteCondominio {
    public void static main(String [] args){
        Apartamento a = new Apartamento();
        a.Incluir("Fulano", 40.00, 101, 2, "Inquilino", 1111-2222);
        Apartamento a1 = new Apartamento();
        a1.Incluir("Fulano", 60.00, 102, 3, "Inquilino", 1111-2222);
        Apartamento a2 = new Apartamento();
        a2.Incluir("Fulano", 40.00, 201, 2, "Inquilino", 1111-2222);
        Apartamento a3 = new Apartamento();
        a3.Incluir("Fulano", 60,00, 202, 3, "Inquilino", 1111-2222);        
    }
}
