
package Predio;

public class Apartamento {
    public Propietario propietario;
    public DespesaApartamento[] despesaApartamento;
    public int numeroDePorta;
    public int quantidadeDeQuartos;
    public String ocupacao;
    public Incluir(Propietario novoPropietario, DespesaApartamento[] novaDespesaApartamento, int novoNumeroDePorta, int novaQuantidadeDeQuartos,, String novaOcupacao){
        propietario = novoPropietario;
        despesaApartamento = novaDespesaApartamento;
        numeroDePorta = novoNumeroDePorta;
        quantidadeDeQuartos = novaQuantidadeDeQuartos;
        ocupacao = novaOcupacao;
    }
}
