
package Predio;

public class TotalDoApartamento {
    public DespesaApartamento[] despesaApartamento;
    public int numeroDaPorta;
    public float somaDoValor;
    public int mesAnoDespesa;
    public Incluir(DespesaApartamento[] novaDespesaApartamento, int novoNumeroDaPorta, float novaSomaDoValor, int novoMesAnoDespesa){
        despesaApartamento = novaDespesaApartamento;
        numeroDaPorta = novoNumeroDaPorta;
        somaDoValor = novaSomaDoValor;
        mesAnoDespesa = novoMesAnoDespesa;
    }
}
