
package Predio;

public class Propietario {
    public String nome;
    public String telefone;
    public Apartamento[] apartamento;
    public Incluir(String novoNome, String novoTelefone, Apartamento[] novoApartamento){
        nome = novoNome;
        telefone = novoTelefone;
        apartamento = novoApartamento;
    }
}
