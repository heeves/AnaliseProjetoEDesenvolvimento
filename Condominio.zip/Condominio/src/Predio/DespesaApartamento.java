
package Predio;

public class DespesaApartamento {
    public DespesaPredio despesaPredio;
    public Apartamento apartamento;
    public TotalDoApartamento totalDoApartamento;
    public int numeroPorta;
    public int numeroDespesa;
    public float valorDespesa;
    public int mesAnoDespesa;
    public void somaValorPagamento(){
        while(numeroDespesa <=1){
            totalDoApartamento += valorDespesa;
        }
    }
    public TotalDoApartamento calculaValorPagamento(){
        return totalDoApartamento;
    }
}
