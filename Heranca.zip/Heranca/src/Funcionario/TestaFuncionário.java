
package Funcionario;

public class TestaFuncionário {
    public static void main(String[] args){
        Horista h = new Horista ("XXXXXXXXXXX", 30);
        h.calculaSalario();
        Mensalista m = new Mensalista("SSSSSSSSSSSSS", 10);
        m.calculaSalario();
    }
}

