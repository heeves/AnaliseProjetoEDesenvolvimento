
package Funcionario;

public class Funcionario {
    private int numFunc;
    public String nome;
    public void calculaSalario(){
        System.out.println("Calculando o salário...");
    }
    public Funcionario(String novoNome){
        nome= novoNome;
        numFunc ++;
    }
    public void finalize(){
        System.out.println("Cancelando funcionário...");
        numFunc --;
    }
}
