
package Funcionario;

public class Horista extends Funcionario{
    public float salarioPorHora;
    public float numeroHora;
    public Horista(String novoNome, float novoNumeroHora) {
        super(novoNome);
        numeroHora = novoNumeroHora;
    }
    @Override
    public void calculaSalario(){
        float salario = salarioPorHora * numeroHora;
        System.out.println("O funcionário deverá receber:"+salario);
    }
}
