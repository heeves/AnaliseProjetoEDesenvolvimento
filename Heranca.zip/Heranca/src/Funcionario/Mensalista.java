
package Funcionario;

public class Mensalista extends Funcionario{
    public float salMensal;
    public float faltas;
    public Mensalista(String novoNome, float novasFaltas) {
        super(novoNome);
        faltas = novasFaltas;
    }
    @Override
    public void calculaSalario(){
        if(faltas == 0)
            System.out.println("o funcionário deverá receber:"+ salMensal);
        else{
            faltas *= 0.02;
            salMensal *=faltas;
            System.out.println("o funcionário deverá receber:"+ salMensal);
        }
    }
}
