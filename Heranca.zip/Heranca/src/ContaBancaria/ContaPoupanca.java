
package ContaBancaria;

public class ContaPoupanca extends ContaBancaria{
    private int diaDeRendimento;
    public ContaPoupanca(String novoCliente, int novoNumConta, float novoSaldo, int novoDiaDeRendimento) {
        super(novoCliente, novoNumConta, novoSaldo);
        diaDeRendimento = novoDiaDeRendimento;
    }
    public int get_diaDeRendimento(){
        return diaDeRendimento;
    }
    public void calcularNovoSaldo(){
        saldo *= 0.005;
        System.out.println("Novo saldo: "+ saldo);
    }
}
