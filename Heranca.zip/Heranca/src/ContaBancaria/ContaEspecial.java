
package ContaBancaria;

public class ContaEspecial extends ContaBancaria{
    private float limite;
    public ContaEspecial(String novoCliente, int novoNumConta, float novoSaldo, float novoLimite) {
        super(novoCliente, novoNumConta, novoSaldo);
        limite = novoLimite;
    }
    public float get_limite(){
        return limite;
    }
    @Override
    public void sacar(float valor){
        if(valor >= saldo+limite)
            System.out.println("Seu saque não pode ser realizado");
        else{
            saldo -= valor;
            System.out.println("Saque realizado com sucesso");
        }            
    }
}
