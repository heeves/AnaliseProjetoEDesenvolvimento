
package ContaBancaria;

public class ContaBancaria {
    private String cliente;
    private int numConta;
    private float saldo;
    public ContaBancaria(String novoCliente, int novoNumConta, float novoSaldo){
        cliente = novoCliente;
        numConta = novoNumConta;
        saldo = novoSaldo;
    }
    public String get_cliente(){
        return cliente;
    }
    public int get_numConta(){
        return numConta;
    }
    public float get_saldo(){
        return saldo;
    }
    public void sacar(float valor){
        if(saldo == 0)
            System.out.println("Saldo insuficientepara saque");
        if(valor > saldo)
            System.out.println("Seu saque é maior que o seu saldo");
        else {
            System.out.println("Saque efetuado com sucesso");
            saldo -= valor;
        }
    }
    public void depositar(float valor){
        if(valor <= 0)
            System.out.println("Depósito inválido");
        else{
            saldo += valor;
            System.out.println("Depósito efetuado com sucesso");
        }
    }
}
