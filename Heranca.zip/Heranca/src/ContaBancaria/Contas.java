
package ContaBancaria;

public class Contas {
    public static void main(String[] args){
        ContaPoupanca cp = new ContaPoupanca("AAAAAAAAAAAAAAA", 1111111111, 10000.0, 01);
        ContaEspecial ce = new ContaEspecial("AAAAAAAAAAAAAAA", 1111111111, 1000.0, 1000.0);
        cp.sacar(100);
        ce.sacar(100);
        cp.depositar(200);
        ce.depositar(200);
        cp.calcularNovoSaldo();
        ce.get_cliente();
        ce.get_numConta();
        ce.get_saldo();
    }
}
