
package Biblioteca;

public class TestaLocacao {
    public static void main(String[] args){
        Autor a = new Autor();
        a.Escrever();
        a.Escrever();
        a.Escrever();
        Edicao e = new Edicao();
        e.publicar();
        Biblioteca b = new Biblioteca();
        b.CadastrarSocio();
        b.CadastrarLocacao("0/0/0", "0/0/0");
    }
}
