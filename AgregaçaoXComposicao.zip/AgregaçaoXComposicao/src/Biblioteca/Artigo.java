
package Biblioteca;

public class Artigo {
    public String titulo;
    public int quantidadeDePaginas;
    public int paginaInicial;
    public Edicao edicao;
}
