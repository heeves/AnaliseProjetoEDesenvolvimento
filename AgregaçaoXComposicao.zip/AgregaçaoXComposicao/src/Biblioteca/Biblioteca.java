
package Biblioteca;

public class Biblioteca {
    public Socio socio;
    public RevistaCientifica revistaCientifica;
    public void CadastrarLocacao(String dataDaLocacao, String dataDaDevolucao){
        if(dataDaLocacao.equals(dataDaDevolucao))
            System.out.println("Data da devolução é igual a data de locação");
    }
    public void CadastrarSocio(){
        System.out.println("Sócio cadastrado com sucesso");
    }
}
