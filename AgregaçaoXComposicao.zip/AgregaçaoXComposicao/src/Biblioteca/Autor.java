
package Biblioteca;

public class Autor {
    public String nome;
    public String endereco;
    public String eMail;
    public String fone;
    public void Escrever(){
        System.out.println("Escrevendo...");
    }
}
