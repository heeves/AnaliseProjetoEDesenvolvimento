
package Biblioteca;

public class Socio {
    public String nome;
    public String endereco;
    public String fone;
    public String email;
    public String dataDeNascimento;
    public Biblioteca biblioteca;
}
