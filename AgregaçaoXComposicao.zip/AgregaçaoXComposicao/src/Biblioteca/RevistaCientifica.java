
package Biblioteca;

public class RevistaCientifica {
    public int ISSN;
    public String titulo;
    public String periodicidade;
    public Biblioteca biblioteca;
    public Edicao edicao;
}
