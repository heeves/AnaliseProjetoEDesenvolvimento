
package Biblioteca;

public class Edicao {
    public int numeroDaEdicao;
    public int volumeDaEdicao;
    public String dataDaEdicao;
    public int tiragem;
    public RevistaCientifica revistacientifica;
    public Artigo artigo;
    public void publicar(){
        System.out.println("Publicando...");
    }
}
