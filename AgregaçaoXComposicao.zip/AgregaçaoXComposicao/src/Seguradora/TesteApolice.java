
package Seguradora;

public class TesteApolice {
    public static void main(String[] args){
        Cliente c = new Cliente();
        Atendente at = new Atendente();
        c.Solicitar();
        at.Registrar();
        at.Gerar("orçamento aceito");
    }
}


  
