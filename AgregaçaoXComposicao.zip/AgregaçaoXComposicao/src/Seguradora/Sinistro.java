
package Seguradora;

public class Sinistro {
    public boolean perdaTotal;
    public boolean furto;
    public boolean motorFundido;
    public String dataDoSinistro;
    public String localDoSinistro;
    public int danos;
    public Apolice apolice;
}
