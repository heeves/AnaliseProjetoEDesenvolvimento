
package Seguradora;

public class Atendente {
    public Apolice apolice;
    public void Registrar(){
        System.out.println("Registrando apólice...");
    }
    public void Gerar(String resposta){
        if(resposta.equals("orçamento aceito"))
            System.out.println("Gerando apólice...");
        else
            System.out.println("Não gere a apólice");
        
    }
}
