package Seguradora;

public class Cliente {
    public Veiculo veiculo;
    public void Solicitar(){
        System.out.println("Solicitando orçamento...");
    }
}
