
package Seguradora;

public class Apolice {
    public String numeroDaApollice;
    public String dataDeEmissao;
    public String dataDeVencimento;
    public float valorDaApolice;
    public String situacaoDaApolice;
    public Atendente atendente;
    public Sinistro sinistro;
    public Parcelas parcelas;
}
