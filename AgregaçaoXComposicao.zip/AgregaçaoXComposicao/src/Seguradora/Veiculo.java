
package Seguradora;

public class Veiculo {
    public String placa;
    public String quilometragemAtual;
    public String marca;
    public String modelo;
    public int anoDeFabricacao;
    public int anoDoModelo;
    public Cliente cliente;
    public Apolice apolice;
}
