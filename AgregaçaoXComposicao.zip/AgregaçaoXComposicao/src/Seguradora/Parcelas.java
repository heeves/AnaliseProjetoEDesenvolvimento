
package Seguradora;

public class Parcelas {
    public int numeroDeParcelas;
    public String dataDeEmissao;
    public String dataDeVencimento;
    public float valorDaParcela;
    public String dataDePagamento;
    public float valorPago;
    public boolean situacaoDaParcela;
}
